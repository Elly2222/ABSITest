package WebApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SQLTest{
    public static void main(String[] args) throws Exception{
        testDb();
    }
        private static void testDb() throws Exception {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ABSIDB", "ABSI", "absi");
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM USERS");
        while (rs.next()) {
            String username = rs.getString("Username");
            String password = rs.getString("Password");
            System.out.println("Username: " + username);
            System.out.println("Password: " + password);
        }
    }
}