package playingcard;

import java.io.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
/**
 *
 * @author Administrator
 */
public class PlayingCard {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String suit[] = {"HEART", "DIAMOND", "SPADE", "CLOVES"};
        String rank[] = {"ACE", "2", "3", "4", "5", "6", "7", "8", "9", "10", "JACK", "QUEEN", "KING"};
        setCombine(suit,rank);
    }
    public static void setCombine(String st[],String rk[]){
        
        List<String> cardList = Arrays.asList(st);
        List<String> rankList = Arrays.asList(rk);
        
        
        String newCard[] = cardList.toArray(st);
        Collections.shuffle(cardList);
        
        for(int j = 0; j < newCard.length; j++){
                
            Collections.shuffle(rankList);
            System.out.println(newCard[j] + rankList); 
            
        }
}
}
