/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playingcards;

/**
 *
 * @author ABSI
 */
public class PlayingCards {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
        // TODO code application logic here

        String[] values = new String[]{"K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2", "A"};

        Card[] deck = new Card[52];

        int i = 0;
        for (Suit suit : Suit.values()) {
            for (String value : values) {
                deck[i++] = new Card(suit, value);
            }
        }
        for (Card card : deck) {
            System.out.println(card.getValue() + " of " + card.getSuit());
        }

    }
}
